def reverse_seq(n):
    return list(range(n, 0, -1))