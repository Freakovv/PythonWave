def get_char(c):
  # Your code goes here ^_^
  return