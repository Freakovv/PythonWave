def symmetric_point(p, q):
    # your code here
    return []