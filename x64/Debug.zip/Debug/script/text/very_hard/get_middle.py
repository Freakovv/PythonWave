def get_middle(s):
    pass