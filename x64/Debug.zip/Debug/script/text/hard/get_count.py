def get_count(sentence):
    pass