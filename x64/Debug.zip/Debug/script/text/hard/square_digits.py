def square_digits(num):
    # Your code here
    pass