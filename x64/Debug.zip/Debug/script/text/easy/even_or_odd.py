def even_or_odd(number):
    pass