def better_than_average(class_points, your_points):
    # Your code here
    return