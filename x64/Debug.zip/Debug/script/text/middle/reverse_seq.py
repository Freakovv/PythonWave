def reverse_seq(n):
    pass