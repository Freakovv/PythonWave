def positive_sum(arr):
    # Your code here
    return 0